
from django.http import HttpResponse
from .models import Question
from django.shortcuts import render

# Create your views here.

def index(request):
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)
def detail(request, question_id):
    return HttpResponse("Сейчас ты просматриваешь вопрос %s." % question_id)
def results(request, question_id):
    responce = "Ты смотришь результаты %s."
    return HttpResponse(responce % question_id)
def vote(request, question_id):
    return HttpResponse("Ты голосуешь за вопрос %s." % question_id)